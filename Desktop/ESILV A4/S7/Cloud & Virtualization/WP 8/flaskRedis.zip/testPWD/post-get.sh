#!/bin/bash

echo "redis database content before POST"
curl localhost:80

echo "POST..."
curl --header "Content-Type: application/json" --request POST --data '{"name":"mydata"}' localhost:80

echo "redis database content after POST"
curl localhost:80
